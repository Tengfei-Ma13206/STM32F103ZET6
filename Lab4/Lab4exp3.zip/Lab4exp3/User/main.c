#include "stm32f10x.h"

void Delay(u32 count)
{
	u32 i;
	for (i=1;i<count;i++);
}

void EIE3810_Key2_EXTIInit(void)// press=low, PE2 EXTI2
{
	RCC->APB2ENR |= 1<<6;//enable GPIOE
	GPIOE->CRL &=0xFFFFF0FF;
	GPIOE->CRL |=0x00000800;//set PE2(key2) to input pull up/down
	GPIOE->ODR |=1<<2;//set key 2 to pull up
	RCC->APB2ENR |= 0x01;//Enable AFIO clock
	AFIO->EXTICR[0] &=0xFFFFF0FF;
	AFIO->EXTICR[0] |=0x00000400;//select PE2 for EXTI2
	EXTI->IMR |=1<<2;//interrupt request from Line 2(EXTI2) is not masked
	//EXTI->FTSR|=1<<2;//falling trigeer enable for EXIT2
	EXTI->RTSR|=1<<2;//rising trigeer enable for EXIT2
	NVIC->IP[8]=0x65;//set interrupt priority as 0b0110 0101
	NVIC->ISER[0] |=(1<<8);// set the Interrupt Set-Enable Register to enable EXTI2
}

void EIE3810_KeyUp_EXTIInit(void)// press=high, PA0, EXIT0
{
	RCC->APB2ENR |= 1<<2;//enable GPIOA
	GPIOA->CRL &=0xFFFFFFF0;
	GPIOA->CRL |=0x00000008;//set PA0(key_Up) to input pull up/down
	GPIOA->ODR |=1<<1;//set key_up to pull up
	RCC->APB2ENR |= 0x01;//Enable AFIO clock
	AFIO->EXTICR[0] &=0xFFFFFFF0;
	AFIO->EXTICR[0] |=0x00000000;//select PA0 for EXTI0
	EXTI->IMR |=1;//interrupt request from Line 0(EXTI0) is not masked
	//EXTI->FTSR|=1;//falling trigeer enalbe for EXTI0
	EXTI->RTSR|=1;//rising trigeer enable for EXTI0
	NVIC->IP[6]=0x95;//set interrupt priority as 0b1001 0101
	//NVIC->IP[6]=0x35;//set interrupt priority as 0b0011 0101
	NVIC->ISER[0] |=(1<<6);//enable EXIT0
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1,temp2;
	temp2=prigroup&0x00000007;//0x7=0b0111, pick the lowest 3 bits
	temp2<<=8;//move to bit 8-10, the grouping field
	temp1=SCB->AIRCR;//get the previous value of AIRCR
	temp1 &=0x0000F8FF;//get bit 0-16 of temp1, 8,9,10 bit is 0
	temp1 |=0x05FA0000;//On writes, write 0x5FA to VECTKEY, otherwise the write is ignored
	temp1 |=temp2;//put the bit 8-10 (PRIGROUP) of temp2 into temp1
	SCB->AIRCR=temp1;//assign prepared temp1 to AIRCR
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR |= 1<<6;//enable GPIOE
	RCC->APB2ENR|=1<<3;//enable GPIOB
	GPIOB->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to set pb5
	GPIOE->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to set pb5
	GPIOB->CRL|=0x00300000;//set PB5(led0) as push pull output
	GPIOE->CRL|=0x00300000;//set PE5(led1) as push pull output
}
void EXTI2_IRQHandler(void)
{
	u8 i;
	
	for (i=0;i<10;i++)
	{
		GPIOB->BRR=1<<5;//for LED0 high
		Delay(3000000);
		GPIOB->BSRR=1<<5;//for LED0 low
		Delay(3000000);
	}
	EXTI->PR=1<<2;// clear the pending bit of EXTI2
}


void EXTI0_IRQHandler(void)
{
	u8 i;
	
	for (i=0;i<10;i++)
	{
		GPIOE->BRR=1<<5;//for LED1 high
		Delay(3000000);
		GPIOE->BSRR=1<<5;//for LED1 low
		Delay(3000000);
	}
	EXTI->PR=1;// clear the pending bit of EXTI0
}

int main(void)
{		
	EIE3810_NVIC_SetPriorityGroup(5);// Set PRIGROUP = 5
	EIE3810_Key2_EXTIInit();//Initialize Key2 as an interrupt input
	EIE3810_KeyUp_EXTIInit();//Initialize Key_up as an interrupt input
	EIE3810_LED_Init();// initialize LED
	GPIOB->BSRR=1<<5;//set LED0 low
	GPIOE->BSRR=1<<5;//set LED1 low
	
	int count=0;
	while(1)
	{
		count++;
	}
}
	
