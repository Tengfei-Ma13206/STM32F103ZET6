#include "stm32f10x.h"

void Delay(u32 count)
{
	u32 i;
	for (i=1;i<count;i++);
}

void EIE3810_Key2_EXTIInit(void)
{
	RCC->APB2ENR |= 1<<6;//enable GPIOE
	GPIOE->CRL &=0xFFFFF0FF;
	GPIOE->CRL |=0x00000800;//set PE2(key2) to input pull up/down
	GPIOE->ODR |=1<<2;//set key 2 to pull up
	RCC->APB2ENR |= 0x01;//Enable AFIO clock
	AFIO->EXTICR[0] &=0xFFFFF0FF;
	AFIO->EXTICR[0] |=0x00000400;//select PE2 for EXTI2
	EXTI->IMR |=1<<2;//interrupt request from Line 2(EXTI2) is not masked
	//EXTI->FTSR|=1<<2;//falling trigeer enable for EXIT2
	EXTI->RTSR|=1<<2;//rising trigeer enable for EXIT2
	NVIC->IP[8]=0x65;//set interrupt priority as 0b0110 0101
	NVIC->ISER[0] |=(1<<8);// set the Interrupt Set-Enable Register to enable EXTI2
}

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1,temp2;
	temp2=prigroup&0x00000007;//0x7=0b0111, pick the lowest 3 bits
	temp2<<=8;//move to bit 8-10, the grouping field
	temp1=SCB->AIRCR;//get the previous value of AIRCR
	temp1 &=0x0000F8FF;//get bit 0-16 of temp1, 8,9,10 bit is 0
	temp1 |=0x05FA0000;//On writes, write 0x5FA to VECTKEY, otherwise the write is ignored
	temp1 |=temp2;//put the bit 8-10 (PRIGROUP) of temp2 into temp1
	SCB->AIRCR=temp1;//assign prepared temp1 to AIRCR
}

void EIE3810_LED_Init(void)
{
	RCC->APB2ENR |= 1<<6;//enable GPIOE
	RCC->APB2ENR|=1<<3;//enable GPIOB
	GPIOB->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to set PB5
	GPIOE->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to set PE5
	GPIOB->CRL|=0x00300000;//set PB5(led0) as push pull output
	GPIOE->CRL|=0x00300000;//set PE5(led1) as push pull output
}
void EXTI2_IRQHandler(void)
{
	u8 i;
	for (i=0;i<10;i++)
	{
		GPIOB->BRR=1<<5;//set LED0 high
		Delay(3000000);
		GPIOB->BSRR=1<<5;//set LED0 low
		Delay(3000000);
	}
	EXTI->PR=1<<2;// clear the pending bit of EXTI2
}

int main(void)
{
	EIE3810_NVIC_SetPriorityGroup(5);// set [5:0] as sub-priority
	EIE3810_Key2_EXTIInit();// initialize key2 as an interrupt input
	EIE3810_LED_Init();// intialize LED
	GPIOB->BSRR=1<<5;//set LED0 low
	
	int count=0;
	while(1)
	{
		GPIOE->BRR=1<<5;//for LED1 high
		Delay(5000000);
		GPIOE->BSRR=1<<5;//for LED1 low
		Delay(5000000);
		count++;
	}
}
	
