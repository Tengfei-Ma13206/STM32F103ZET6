#include "stm32f10x.h"
#include "EIE3810_USART.h"

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//Separate USARTDIV into two parts
	mantissa<<=4;
	mantissa+=fraction;//let the number fix the rule of RCC, the LSB 4 bits is fra
	//dealing with the number for baudrate
	RCC->APB2ENR |= 1<<2; //enable GPIOA	
	GPIOA->CRL &= 0xFFFF00FF; //enable GPIOA
	GPIOA->CRL |= 0x00008B00; //enable GPIOA,pa2= input pull up/down,pa3=al fu out push put with 50Hz
	RCC->APB1RSTR |= 1<<17; //resetUSART2,APB1 is for USART2
	RCC->APB1RSTR &= ~(1<<17); //??why do the inverse?
	USART2->BRR=mantissa;//use the USARTDIV number to set the cro res
	USART2->CR1=0x2008; //CR1 res is for control, 2 for bit13 to 1,USART enable, 8 for Bit 0 SBK, Break character will be transmitted
	//Bit 1 RWU: Receiver wakeup, Receiver in mute mode. Bit 3 TE: Transmitter enable, 1: Transmitter is enabled
}

void EIE3810_USART1_init(u32 pclk1, u32 baudrate)
{
	//USART1
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//Separate USARTDIV into two parts
	mantissa<<=4;
	mantissa+=fraction;//let the number fix the rule of RCC, the LSB 4 bits is fra
	//dealing with the number for baudrate
	//below is unchanged
	RCC->APB2ENR |= 1<<2; //enable GPIOA	
	GPIOA->CRH &= 0xFFFFF00F; //enable GPIOA
	GPIOA->CRH |= 0x000008B0; //enable GPIOA,pa9= input pull up/down,pa10=al fu out push put with 50Hz
	RCC->APB2RSTR |= 1<<14; //resetUSART1, change 17 to 14,APB! to APB2
	RCC->APB2RSTR &= ~(1<<14); //??why do the inverse?
	USART1->BRR=mantissa;//use the USARTDIV number to set the cro res, same as USART1
	USART1->CR1=0x2008; //CR1 res is for control, 2 for bit13 to 1,USART enable, 8 for Bit 0 SBK, Break character will be transmitted
	USART1->CR1|=1<<5;//interrupt enable, RXNE interrupt enable,add in lab4
	USART1->CR1|=1<<2;//receive enable, add in lab4
	//Bit 1 RWU: Receiver wakeup, Receiver in mute mode. Bit 3 TE: Transmitter enable, 1: Transmitter is enabled
}

void USART_print(u8 USARTport, char*st)
{
	u8 i=0;
	while(st[i] !=0x00)
	{
		if (USARTport == 1) 
		{
			USART1->DR=st[i];
			while((USART1->SR|0xFFFFFF7F)==0xFFFFFF7F)
			{
				;
			}
		}
		else if (USARTport == 2) 
		{
			USART2->DR=st[i];
			while((USART2->SR|0xFFFFFF7F)==0xFFFFFF7F)
			{
				;
			}
		}
		if (i==255) break;
		i++;
	}
}
		

