#include "stm32f10x.h"
#include "EIE3810_Clock.h"

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;
	u8 temp=0;
	RCC->CR |= 0x00010000; //bit 16 is 1, HSE on(8Hz)
	while(!((RCC->CR>>17)&0x1));//waitting for something?
	RCC->CFGR &= 0xFFFDFFFF; //bit 17 is 1, HSE not divided
	RCC->CFGR |= 1<<16; //bit 16 is 1, the HSE is sellected as PLL input clock
	RCC->CFGR |= PLL<<18; //0111, PLL input clock*9 (72Hz)
	RCC->CR |=0x01000000;//PLL on
	while(!(RCC->CR>>25));//Add comments
	RCC->CFGR &=0xFFFFFFFE;//LSB==0(needed)
	RCC->CFGR |=0x00000002;//LSBs of CFGR=10PLL selected as system clock
	while(temp !=0x02) //Add comments
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; // temp=0x02 anyway
	}	
	RCC->CFGR &= 0xFFFFDC0F;//add,bit 4-7(x second)for AHB clock, AHB not divided. D neam 1101, let bit 13-11 be 0xx, for APB2 not divided
	RCC->CFGR |= 0x00000400;//bit 11,10,9,8=x100,for APB1's PLCK1, HCLK divided by 2(36Hz)
	
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //USART2 clock enable
	RCC->APB2ENR |= 1<<14; //add,USART1 clock enable, why there is inversr?
}


