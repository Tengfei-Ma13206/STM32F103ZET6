#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"

void Delay(u32);
void EIE3810_TFTLCD_FillRectangle(u16 start_x, u16 length_x,
	u16 start_y, u16 length_y, u16 color)
{
	u32 index=0;
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(start_x>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(start_x & 0xFF);//start with x = start_x
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)&0xFF);//end with x = (length_x + start_x - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(start_y>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(start_y&0xFF);//start with y = start_y
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)& 0xFF);// end with y = (length_y + start_y - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (index=0;index<length_x*length_y;index++)
	{
		EIE3810_TFTLCD_WrData(color);//set the rectangle as "color"
	}
}

int main(void)
{
	EIE3810_TFTLCD_Init();//initialize LCD
	Delay(1000000);
	EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
	EIE3810_TFTLCD_FillRectangle(100,100,100,100,YELLOW);// draw a yellow rectangle
	while (1);
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}


