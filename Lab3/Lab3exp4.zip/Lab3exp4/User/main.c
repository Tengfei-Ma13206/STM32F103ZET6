#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"
#include "Font.H"

void Delay(u32);
void EIE3810_TFTLCD_FillRectangle(u16 start_x, u16 length_x,
	u16 start_y, u16 length_y, u16 color)
{
	u32 index=0;
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(start_x>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(start_x & 0xFF);//start with x = start_x
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)&0xFF);//end with x = (length_x + start_x - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(start_y>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(start_y&0xFF);//start with y = start_y
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)& 0xFF);// end with y = (length_y + start_y - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (index=0;index<length_x*length_y;index++)
	{
		EIE3810_TFTLCD_WrData(color);//set the rectangle as "color"
	}
}

void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor)
{
	u8 column=0;// the pattern of one column
	for (u16 i=0;i<16;i++)
	{
		column = asc2_1608[ASCII-32][i];
		for (u16 j=0;j<8;j++)// bit j of column
		{
			//draw pixel
			if ((column%2)==1)// the bit j of column is 1
			{
				if (i%2==0)//upper column
				{
					EIE3810_TFTLCD_DrawDot(x+i/2, y+8-j, color);// draw dot of character
				}
				else// lower column
				{
					EIE3810_TFTLCD_DrawDot(x+(i-1)/2, y+(16-j),color);// draw dot of character
				}
			}
			else// the bit j of column is 0
			{
				if (i%2==0)//upper column
				{
					EIE3810_TFTLCD_DrawDot(x+i/2, y+8-j, bgcolor);// draw dot of character background
				}
				else//lower column
				{
					EIE3810_TFTLCD_DrawDot(x+(i-1)/2, y+(16-j),bgcolor);// draw dot of character background
				}
			}
			column=column/2;//remove the LSB of column
		}
		
	}
}

void EIE3810_TFTLCD_SevenSegment(u16 start_x, u16 start_y,u8 digit,u16 color)
{
	if (digit==1)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);// right lower
	}
	else if (digit==2)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);// upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);// left lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
	}
		else if (digit==3)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
	  EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
	}
	else if (digit==4)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	  EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
	}
	else if (digit==5)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	}
	else if (digit==6)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	}
		
	else if (digit==7)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	  EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
	}
	else if (digit==8)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper	
	}
	else if (digit==9)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
	}
	else if (digit==0)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
	}
}

void PrintString(u16 x, u16 y, char*st, u16 color, u16 bgcolor)
{
	u16 charWidth=8;//width of every character
	u8 i=0;
	while (st[i]!=0x00)
	{
		EIE3810_TFTLCD_ShowChar(x+i*charWidth, y,st[i], color, bgcolor);//print character
		if (i==59) break;// max nunber of character is 60
		i++;
	}	
}
void exp_1()
{
//draw background
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(0>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(0 & 0xFF);// start with x = 0
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(479>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(479&0xFF);//end with x = 479
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(0>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(0&0xFF);//start with y=0
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((799)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(799& 0xFF);//end with y=799
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<480*800;index++)
	{
		EIE3810_TFTLCD_WrData(WHITE);//set white background
	}
//draw black line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x=10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x=29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(10&0xFF);//start with y=10
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((10)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(10& 0xFF);//end with y=10
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(BLACK);//set the line as black
	}
//draw white line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(20>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(20&0xFF);//start with y = 20
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(20>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(20& 0xFF);//end with y = 20
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(WHITE);//set the line as white color
		
	}
//draw green line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(30>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(30&0xFF);//start with y = 30
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(30>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(30& 0xFF);//end with y = 30
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(GREEN);//set the line as green
		
	}
//draw red line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x  = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(40>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(40&0xFF);//start with y = 40
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(40>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(40& 0xFF);//end with y = 40
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(RED);//set the line as red
	}
//draw blue line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x=10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x=29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(50>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(50&0xFF);//start with y=50
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(50>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(50& 0xFF);//end with y=50
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(BLUE);//set the line as blue
	}
}

void exp_2()
{
		EIE3810_TFTLCD_FillRectangle(230,239,0,400,WHITE);// set right upper region as white (background)
		EIE3810_TFTLCD_FillRectangle(340,100,100,100,YELLOW);// draw a yellow rectangle
}

void exp_3()
{
		u16 s_x=100;
		u16 s_y=600;
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);// set left lower region as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,9,BLUE);// print blue 9 on the screen
		Delay(10000000);// wait one second
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,8,BLUE);// print blue 8 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,7,BLUE);// print blue 7 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,6,BLUE);// print blue 6 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,5,BLUE);// print blue 5 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,4,BLUE);// print blue 4 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,3,BLUE);// print blue 3 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,2,BLUE);// print blue 2 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,1,BLUE);// print blue 1 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,240,399,400,WHITE);
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,0,BLUE);// print blue 0 on the screen
		Delay(10000000);
}

	
void exp_4()
{
		EIE3810_TFTLCD_FillRectangle(240, 240,400,399,GREEN);//set the right lower region as green (background)
		PrintString(280,480,"121090406",BLACK,GREEN);// print my student ID with black character and green bgcolor
}
	
//void exp4()
//{
//		EIE3810_TFTLCD_FillRectangle(0, 479,0,799,GREEN);
//		PrintString(280,480,"121090406",BLACK,GREEN);
//}


int main(void)
{
	EIE3810_TFTLCD_Init();//initialize LCD
	
	//exp4();
	//while(1);

	EIE3810_TFTLCD_FillRectangle(0, 479,0,799,WHITE);// set background as white
	exp_1();
	exp_2();
	exp_4();
	while (1)
	{
		exp_3();
	}
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}

