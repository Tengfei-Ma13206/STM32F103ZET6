#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"

void Delay(u32);


int main(void)
{
	
	EIE3810_TFTLCD_Init();// initialize LCD
//big endian
//draw background
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(0>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(0 & 0xFF);// start with x = 0
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(479>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(479&0xFF);//end with x = 479
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(0>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(0&0xFF);//start with y=0
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((799)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(799& 0xFF);//end with y=799
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<480*800;index++)
	{
		EIE3810_TFTLCD_WrData(WHITE);//set white background
	}
//draw black line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x=10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x=29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(10&0xFF);//start with y=10
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((10)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(10& 0xFF);//end with y=10
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(BLACK);//set the line as black
	}
//draw white line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(20>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(20&0xFF);//start with y = 20
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(20>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(20& 0xFF);//end with y = 20
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(WHITE);//set the line as white color
		
	}
//draw green line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(30>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(30&0xFF);//start with y = 30
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(30>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(30& 0xFF);//end with y = 30
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(GREEN);//set the line as green
		
	}
//draw red line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x  = 10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x = 29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(40>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(40&0xFF);//start with y = 40
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(40>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(40& 0xFF);//end with y = 40
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(RED);//set the line as red
	}
//draw blue line
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(10>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(10 & 0xFF);//start with x=10
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData(29>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData(29&0xFF);//end with x=29
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(50>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(50&0xFF);//start with y=50
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData(50>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData(50& 0xFF);//end with y=50
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (int index=0;index<20;index++)
	{
		EIE3810_TFTLCD_WrData(BLUE);//set the line as blue
	}
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}



