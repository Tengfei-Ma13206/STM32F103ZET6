#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"

void Delay(u32);

int main(void)
{
	int i, j;
	EIE3810_TFTLCD_Init();
	Delay(1000000);	
	for (i=0;i<10;i++)
	{
		for (j=0;j<10;j++)
		{
			EIE3810_TFTLCD_DrawDot(100+i, 100+j, RED);
		}
	}	

}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}

