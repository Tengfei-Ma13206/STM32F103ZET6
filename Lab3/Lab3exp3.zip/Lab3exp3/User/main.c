#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"
#include "Font.H"

void Delay(u32);
void EIE3810_TFTLCD_FillRectangle(u16 start_x, u16 length_x,
	u16 start_y, u16 length_y, u16 color)
{
	u32 index=0;
	EIE3810_TFTLCD_WrCmd(0x2A00);
	EIE3810_TFTLCD_WrData(start_x>>8);
	EIE3810_TFTLCD_WrCmd(0x2A01);
	EIE3810_TFTLCD_WrData(start_x & 0xFF);//start with x = start_x
	
	EIE3810_TFTLCD_WrCmd(0x2A02);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2A03);
	EIE3810_TFTLCD_WrData((length_x+start_x-1)&0xFF);//end with x = (length_x + start_x - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2B00);
	EIE3810_TFTLCD_WrData(start_y>>8);
	EIE3810_TFTLCD_WrCmd(0x2B01);
	EIE3810_TFTLCD_WrData(start_y&0xFF);//start with y = start_y
	
	EIE3810_TFTLCD_WrCmd(0x2B02);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)>>8);
	EIE3810_TFTLCD_WrCmd(0x2B03);
	EIE3810_TFTLCD_WrData((length_y+start_y-1)& 0xFF);// end with y = (length_y + start_y - 1)
	
	EIE3810_TFTLCD_WrCmd(0x2C00);
	for (index=0;index<length_x*length_y;index++)
	{
		EIE3810_TFTLCD_WrData(color);//set the rectangle as "color"
	}
}

void EIE3810_TFTLCD_SevenSegment(u16 start_x, u16 start_y,u8 digit,u16 color)
{
	if (digit==1)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);// right lower
	}
	else if (digit==2)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);// upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);// left lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
	}
		else if (digit==3)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
	  EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
	}
	else if (digit==4)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	  EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
	}
	else if (digit==5)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	}
	else if (digit==6)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);// lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	}
		
	else if (digit==7)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
	  EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
	}
	else if (digit==8)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper	
	}
	else if (digit==9)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-75,10,color);// middle
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
	}
	else if (digit==0)
	{
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-10,10,color);//lower
		EIE3810_TFTLCD_FillRectangle(start_x+10,55,start_y-140,10,color);//upper
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-65,55,color);//right lower
		EIE3810_TFTLCD_FillRectangle(start_x+65,10,start_y-130,55,color);// right upper
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-65,55,color);//left lower
		EIE3810_TFTLCD_FillRectangle(start_x,10,start_y-130,55,color);//left upper
	}
}

int main(void)
{

	EIE3810_TFTLCD_Init();// initialize LCD
	Delay(1000000);
	// calculate the position of number as center of screen
	u16 s_x=203;// 480/2 - 74/2
	u16 s_y=470;// 800/2 + 140/2
	
	//EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);
	//EIE3810_TFTLCD_SevenSegment(s_x,s_y,8,BLUE);
	//while(1);

	while(1)
	{
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,9,BLUE);// print blue 9 on the screen
		Delay(10000000);// wait one second
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,8,BLUE);// print blue 8 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,7,BLUE);// print blue 7 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,6,BLUE);// print blue 6 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,5,BLUE);// print blue 5 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,4,BLUE);// print blue 4 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,3,BLUE);// print blue 3 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,2,BLUE);// print blue 2 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,1,BLUE);// print blue 1 on the screen
		Delay(10000000);
		EIE3810_TFTLCD_FillRectangle(0,479,0,799,WHITE);// set background as white
		EIE3810_TFTLCD_SevenSegment(s_x,s_y,0,BLUE);// print blue 0 on the screen
		Delay(10000000);
	}
}

void Delay(u32 count) //Use looping for delay
{
	u32 i;
	for (i=0;i<count;i++);
}





