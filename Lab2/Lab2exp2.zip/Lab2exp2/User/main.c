#include "stm32f10x.h"
void EIE3810_clock_tree_init(void);
void EIE3810_USART2_init(u32, u32);
void EIE3810_USART1_init(u32, u32);
void Delay(u32);


int main(void)
{
	EIE3810_clock_tree_init();
	EIE3810_USART1_init(72, 9600);
	//USART_print(1,"1234567890"); //This line will be used in Experiment 3

	Delay(10000000);
	USART1->DR = 0x31;//1 on data register of USART1
	Delay(50000);		
	USART1->DR = 0x32;//2
	Delay(50000);
	USART1->DR = 0x31;//1
	Delay(50000);
	USART1->DR = 0x30;//0
	Delay(50000);
	USART1->DR = 0x39;//9
	Delay(50000);
	USART1->DR = 0x30;//0
	Delay(50000);
	USART1->DR = 0x34;//4
	Delay(50000);
	USART1->DR = 0x30;//0
	Delay(50000);
	USART1->DR = 0x36;//6
	Delay(50000);
	
	
}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;//0111 -> PLL input clock * 9
	u8 temp=0;
	RCC->CR |= 0x00010000; //Enable High Speed External oscillator: set bit16 of control register as 1
	while(!((RCC->CR>>17)&0x1));//wait for HSE oscillator ready
	RCC->CFGR &= 0xFFFDFFFF; //HSE clock is not divided
	RCC->CFGR |= 1<<16; //HSE oscillator clock selected as PLL input clock
	RCC->CFGR |= PLL<<18; //PLL input clock * 9
	RCC->CR |=0x01000000;//Enable PLL
	while(!(RCC->CR>>25));//wait for PLL locked: be stable
	RCC->CFGR &=0xFFFFFFFE;//10->PLL selected as system clock
	RCC->CFGR |=0x00000002;//PLL selected as system clock
	while(temp !=0x02) //check if system clock switch status is "10:PLL used as system clock"
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; //Assign system clock switch status to temp
	}	
	RCC->CFGR &= 0xFFFFFC0F;//SYSCLK not divided
	RCC->CFGR |= 0x00000400;//HCLK divided by 2
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //Enable USART2
	RCC->APB2ENR |= 1<<14; //Enable USART1 -
}

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//separate USARTDIV into two parts -
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //reset IO port A
	GPIOA->CRL &= 0xFFFF00FF; //PA2 max speed 50MHz,Alternate Function Output Push-pull;
	                          //PA3 Input with pull-up/pull-down
	GPIOA->CRL |= 0x00008B00; //PA2 max speed 50MHz,Alternate Function Output Push-pull;
														//PA3 Input with pull-up/pull-down
	RCC->APB1RSTR |= 1<<17; //reset USART2
	RCC->APB1RSTR &= ~(1<<17); //No effect
	USART2->BRR=mantissa;//the USART Divider -
	USART2->CR1=0x2008; //bit0 = 0:no break character is transmitted
											//bit1 = 0:Receiver in active mode  
											//bit2 = 0:Receiver is disabled
											//bit3 = 1:Transmitter is enabled
											//bit4 = 0:IDLE Interrupt is inhibited
											//bit5 = 0:RXNE Interrupt is inhibited
											//bit6 = 0:Transmission complete interrupt is inhibited
											//bit7 = 0:TXE interrupt is inhibited
											//bit8 = 0:PE interrupt is inhibited
											//bit9 = 0:Even parity
											//bit10 = 0:Parity control disabled
											//bit11 = 0:Idle Line
											//bit12 = 0:Start bit, 8Data bits,n Stop bit
											//bit13 = 1:USART enabled
}

void EIE3810_USART1_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//separate USARTDIV into two parts -
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //reset IO port A
	GPIOA->CRH &= 0xFFFFF00F; //PA9 max speed 50MHz,Alternate Function Output Push-pull;
	                          //PA10 Input with pull-up/pull-down
	GPIOA->CRH |= 0x000008B0; //PA9 max speed 50MHz,Alternate Function Output Push-pull;
														//PA10 Input with pull-up/pull-down
	RCC->APB2RSTR |= 1<<14; //reset USART1
	RCC->APB2RSTR &= ~(1<<14); //No effect
	USART1->BRR=mantissa;//the USART Divider -
	USART1->CR1=0x2008; //bit0 = 0:no break character is transmitted
											//bit1 = 0:Receiver in active mode  
											//bit2 = 0:Receiver is disabled
											//bit3 = 1:Transmitter is enabled
											//bit4 = 0:IDLE Interrupt is inhibited
											//bit5 = 0:RXNE Interrupt is inhibited
											//bit6 = 0:Transmission complete interrupt is inhibited
											//bit7 = 0:TXE interrupt is inhibited
											//bit8 = 0:PE interrupt is inhibited
											//bit9 = 0:Even parity
											//bit10 = 0:Parity control disabled
											//bit11 = 0:Idle Line
											//bit12 = 0:Start bit, 8Data bits,n Stop bit
											//bit13 = 1:USART enabled
}

