#include "stm32f10x.h"
#include "EIE3810_Clock.h"
#include "EIE3810_USART.h"
void Delay(u32);

int main(void)
{
	EIE3810_clock_tree_init();
	EIE3810_USART1_init(72, 9600);
	EIE3810_USART2_init(36, 9600);
	Delay(10000000);
	USART_print(1,"1234567890");
	USART_print(2,"121090406");
}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}

