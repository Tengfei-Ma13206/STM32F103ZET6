#include "stm32f10x.h"
#include "EIE3810_USART.h"

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//separate USARTDIV into two parts -
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //reset IO port A
	GPIOA->CRL &= 0xFFFF00FF; //PA2 max speed 50MHz,Alternate Function Output Push-pull;
	                          //PA3 Input with pull-up/pull-down
	GPIOA->CRL |= 0x00008B00; //PA2 max speed 50MHz,Alternate Function Output Push-pull;
														//PA3 Input with pull-up/pull-down
	RCC->APB1RSTR |= 1<<17; //reset USART2
	RCC->APB1RSTR &= ~(1<<17); //No effect
	USART2->BRR=mantissa;//the USART Divider -
	USART2->CR1=0x2008; //bit0 = 0:no break character is transmitted
											//bit1 = 0:Receiver in active mode  
											//bit2 = 0:Receiver is disabled
											//bit3 = 1:Transmitter is enabled
											//bit4 = 0:IDLE Interrupt is inhibited
											//bit5 = 0:RXNE Interrupt is inhibited
											//bit6 = 0:Transmission complete interrupt is inhibited
											//bit7 = 0:TXE interrupt is inhibited
											//bit8 = 0:PE interrupt is inhibited
											//bit9 = 0:Even parity
											//bit10 = 0:Parity control disabled
											//bit11 = 0:Idle Line
											//bit12 = 0:Start bit, 8Data bits,n Stop bit
											//bit13 = 1:USART enabled
}

void EIE3810_USART1_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;//separate USARTDIV into two parts -
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //reset IO port A
	GPIOA->CRH &= 0xFFFFF00F; //PA9 max speed 50MHz,Alternate Function Output Push-pull;
	                          //PA10 Input with pull-up/pull-down
	GPIOA->CRH |= 0x000008B0; //PA9 max speed 50MHz,Alternate Function Output Push-pull;
														//PA10 Input with pull-up/pull-down
	RCC->APB2RSTR |= 1<<14; //reset USART1
	RCC->APB2RSTR &= ~(1<<14); //No effect
	USART1->BRR=mantissa;//the USART Divider -
	USART1->CR1=0x2008; //bit0 = 0:no break character is transmitted
											//bit1 = 0:Receiver in active mode  
											//bit2 = 0:Receiver is disabled
											//bit3 = 1:Transmitter is enabled
											//bit4 = 0:IDLE Interrupt is inhibited
											//bit5 = 0:RXNE Interrupt is inhibited
											//bit6 = 0:Transmission complete interrupt is inhibited
											//bit7 = 0:TXE interrupt is inhibited
											//bit8 = 0:PE interrupt is inhibited
											//bit9 = 0:Even parity
											//bit10 = 0:Parity control disabled
											//bit11 = 0:Idle Line
											//bit12 = 0:Start bit, 8Data bits,n Stop bit
											//bit13 = 1:USART enabled
}

void USART_print(u8 USARTport, char*st)
{
	u8 i=0;
	while(st[i] !=0x00)
	{
		if (USARTport == 1) 
		{
			USART1->DR=st[i];
			while((USART1->SR >> 7 & 1) != 1);
		}
		if (USARTport == 2) 
		{
			USART2->DR=st[i];
			while((USART2->SR >> 7 & 1) != 1);
		}
		//Delay(50000);
		if (i==255) break;
		i++;
	}
}
		
		

