#include "stm32f10x.h"
#include "EIE3810_Clock.h"

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;//0111 -> PLL input clock * 9
	u8 temp=0;
	RCC->CR |= 0x00010000; //Enable High Speed External oscillator: set bit16 of control register as 1
	while(!((RCC->CR>>17)&0x1));//wait for HSE oscillator ready
	RCC->CFGR &= 0xFFFDFFFF; //HSE clock is not divided
	RCC->CFGR |= 1<<16; //HSE oscillator clock selected as PLL input clock
	RCC->CFGR |= PLL<<18; //PLL input clock * 9
	RCC->CR |=0x01000000;//Enable PLL
	while(!(RCC->CR>>25));//wait for PLL locked: be stable
	RCC->CFGR &=0xFFFFFFFE;//10->PLL selected as system clock
	RCC->CFGR |=0x00000002;//PLL selected as system clock
	while(temp !=0x02) //check if system clock switch status is "10:PLL used as system clock"
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; //Assign system clock switch status to temp
	}	
	RCC->CFGR &= 0xFFFFFC0F;//SYSCLK not divided
	RCC->CFGR |= 0x00000400;//HCLK divided by 2
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //Enable USART2
	RCC->APB2ENR |= 1<<14; //Enable USART1 -
}



