#include "EIE3810_Buzzer.h"
void EIE3810_Buzzer_Init()
{
	RCC->APB2ENR|= 1<<3;//ENABLE GPIOB
	GPIOB->CRH &=0xFFFFFFF0;
	GPIOB->CRH |=0X00000003;
}

void Buzzer_Toggle()
{
	int i;
	GPIOB->BSRR = 1 << 8;//buzzer on
	for(i = 0; i < 100000; i++);
	GPIOB->BRR = 1 << 8;//buzzer off
}