#include "EIE3810_USART.h"

void EIE3810_USART2_init(u32 pclk1, u32 baudrate)
{
	//USART2
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;
	mantissa<<=4;
	mantissa+=fraction;
	
	RCC->APB2ENR |= 1<<2; //Add comments	
	GPIOA->CRL &= 0xFFFF00FF; //Add comments
	GPIOA->CRL |= 0x00008B00; //Add comments
	RCC->APB1RSTR |= 1<<17; //Add comments
	RCC->APB1RSTR &= ~(1<<17); //Add comments
	USART2->BRR=mantissa;//Add comments
	USART2->CR1=0x2008; //Add comments
}

void EIE3810_USART1_init(u32 pclk1, u32 baudrate)
{
	//USART1
	float temp;
	u16 mantissa;
	u16 fraction;
	temp=(float) (pclk1*1000000)/(baudrate*16);
	mantissa=temp;
	fraction=(temp-mantissa)*16;
	mantissa<<=4;
	mantissa+=fraction;
	RCC->APB2ENR |= 1<<2; //gpioa	ENABLE
	RCC->APB2ENR |= 1<<14; //gpioa	ENABLE
	
	
	GPIOA->CRH &= 0xFFFFF00F; //PA9/PA10 CLEAR  
	GPIOA->CRH |= 0x000008B0; //PA9 PA10 RESET
	RCC->APB2RSTR |= 1<<14; //usart1 reset
	RCC->APB2RSTR &= ~(1<<14); //USART1 CLAER OTHERS
	USART1->BRR=mantissa;//BAURD RATE DOESN'T CHANGE
	USART1->CR1=0x2008; //SAME SETTING AS USART2
	
	USART1->CR1 |=1<<2;
	USART1->CR1 |=1<<5;
}

void USART_print (u8 USARTport, char *st)
{
	u8 i =0;
	while (st[i] != 0x00)
	{
	if (USARTport == 1){ USART1->DR = st[i];
	while (!(USART1 ->SR & (1<<7)));
	}
	if (USARTport == 2){ USART2->DR = st[i];
	while (!(USART2 ->SR & (1<<7)));
	}
//		Delay(50000);
//		while ((!(USART1 ->SR & (1<<7))) || !(USART2 ->SR & (1<<7)));
			
		if (i == 255) break;
		i ++;
	}
}

void EIE3810_USART1_EXTIInit(void){
	NVIC->IP[37] = 0x65;//set the priority of USART1 to be 0x65
	NVIC->ISER[1] |= 1<<5;//enable the usart1
}
