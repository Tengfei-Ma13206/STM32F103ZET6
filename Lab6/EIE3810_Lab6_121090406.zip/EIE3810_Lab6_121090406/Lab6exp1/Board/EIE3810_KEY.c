#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"

void EIE3810_Key2_EXTIInit(void){
	RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFFFF0FF;
	GPIOE->CRL |= 0x00000800;
	GPIOE->ODR |= 1<<2;
	RCC->APB2ENR |= 0x01;
	AFIO->EXTICR[0] &= 0xFFFFF0FF;
	AFIO->EXTICR[0] |= 0x00000400;
	EXTI->IMR |= 1<<2;
//	EXTI ->FTSR |= 1<<2;//falling edge trigger
		EXTI ->RTSR |= 1<<2;//rising edge trigger

	NVIC ->IP[8] = 0X65;
	NVIC->ISER[0] |= (1<<8);
}

void EIE3810_KeyUp_EXTIInit(void){
	RCC -> APB2ENR |= 1 << 2;//ENABLE THE GPIOA CLOCK
	GPIOA->CRL &=0xFFFFFFF0;
	GPIOA->CRL |=0X00000008;
	GPIOA->ODR &= 0;
	
	RCC->APB2ENR |= 0x01;//
	AFIO->EXTICR[0] &= 0xFFFFFFF0;//clrear 
	AFIO->EXTICR[0] |= 0x00000000;//pinA is related to 0
	
	EXTI->IMR |= 1<<0;
	EXTI ->FTSR |= 1<<0;//falling edge trigger
	
	NVIC ->IP[6] = 0X35;//change 65 to 35
	NVIC->ISER[0] |= (1<<6);//thr number is 6 for EXTI0
}

void EIE3810_Key0_EXTIInit(void){
	RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFF0FFFF;
	GPIOE->CRL |= 0x00080000;
	GPIOE->ODR |= 1<<4;
	RCC->APB2ENR |= 0x01;
	AFIO->EXTICR[0] &= 0xFFF0FFFF;
	AFIO->EXTICR[0] |= 0x00040000;
	EXTI->IMR |= 1<<4;
//	EXTI ->FTSR |= 1<<4;//falling edge trigger
		EXTI ->RTSR |= 1<<4;//rising edge trigger

	NVIC ->IP[10] = 0X35;
	NVIC->ISER[0] |= (1<<10);
}

void EIE3810_Key1_EXTIInit(void){
	RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFFF0FFF;
	GPIOE->CRL |= 0x00008000;
	GPIOE->ODR |= 1<<3;
	RCC->APB2ENR |= 0x01;
	AFIO->EXTICR[0] &= 0xFFFF0FFF;
	AFIO->EXTICR[0] |= 0x00004000;
	EXTI->IMR |= 1<<4;
//	EXTI ->FTSR |= 1<<4;//falling edge trigger
		EXTI ->RTSR |= 1<<3;//rising edge trigger

	NVIC ->IP[9] = 0X65;
	NVIC->ISER[0] |= (1<<9);
}

void EIE3810_Key_Init(void){
	//KEY1
	RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFFF0FFF;
	GPIOE->CRL |= 0x00008000;
	GPIOE->ODR |= 1<<3;
	
	//KEY0
	RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFF0FFFF;
	GPIOE->CRL |= 0x00080000;
	GPIOE->ODR |= 1<<4;
	
	//UP
		RCC -> APB2ENR |= 1 << 2;//ENABLE THE GPIOA CLOCK
	GPIOA->CRL &=0xFFFFFFF0;
	GPIOA->CRL |=0X00000008;
	GPIOA->ODR &= 0;
	
	//KEY2
		RCC->APB2ENR |= 1<<6;
	GPIOE->CRL &= 0xFFFFF0FF;
	GPIOE->CRL |= 0x00000800;
	GPIOE->ODR |= 1<<2;
}

u8 key1_read(void){
	if ((GPIOE->IDR>>3 & 0x1) == 0) return 1;//press low
	else return 0;
}

u8 key0_read(void){
	if ((GPIOE->IDR>>4 & 0x1) == 0) return 1;//press low
	else return 0; 
}

u8 key2_read(void){
	if ((GPIOE->IDR>>2 & 0x1) == 0) return 1;//press low
		else return 0; 
}

u8 keyu_read(void){
	if ((GPIOA->IDR>>0 & 0x1) == 1) return 1;	else return 0; //press high
}
