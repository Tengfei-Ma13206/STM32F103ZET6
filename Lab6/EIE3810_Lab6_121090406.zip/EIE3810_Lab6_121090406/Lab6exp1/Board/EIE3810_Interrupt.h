#ifndef __EIE3810_INTERRUPT_H
#define __EIE3810_INTERRUPT_H
#include "stm32f10x.h"

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_TIM3_Init(u16 arr, u16 psc);
void EIE3810_TIM4_Init(u16 arr, u16 psc);
	
#endif
