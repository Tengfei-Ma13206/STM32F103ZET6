#ifndef __EIE3810_JOYPAD_H
#define __EIE3810_JOYPAD_H
#include "stm32f10x.h"

void Delay(u32 count);
void JOYPAD_Init(void);
u8 JOYPAD_Read(void);

#endif
