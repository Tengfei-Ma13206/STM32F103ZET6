#include "EIE3810_Interrupt.h"

void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1, temp2;
	temp2 = prigroup &0x00000007;
	temp2 <<= 8;
	temp1 = SCB->AIRCR;
	temp1 &=0x0000F8FF;
	temp1 |= 0x05FA0000;
	temp1 |= temp2;
	SCB->AIRCR = temp1;
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	RCC->APB1ENR |= 1<<1; //tim3 ENABLE
	TIM3->ARR = arr;//SEWT THE PRESCALER VALUE
	TIM3->PSC = psc;//set the pscvaule
	TIM3->DIER |= 1 <<0;//UPDATE INTERRUPT ENABLE
	TIM3->CR1 |= 0X01; //COUNTER ENABLE
	NVIC->IP[29] = 0X45; //SET THE PRIORITY OF TIM3
	NVIC->ISER[0] = (1<<29); //InterruptType SET ENABLE
}

void EIE3810_TIM4_Init(u16 arr, u16 psc)
{
	RCC->APB1ENR |= 1<<2; //tim4 ENABLE
	TIM4->ARR = arr;//SEWT THE PRESCALER VALUE
	TIM4->PSC = psc;//set the pscvaule
	TIM4->DIER |= 1 <<0;//UPDATE INTERRUPT ENABLE
	TIM4->CR1 |= 0X01; //COUNTER ENABLE
	NVIC->IP[30] = 0X45; //SET THE PRIORITY OF TIM4
	NVIC->ISER[0] = (1<<30); //InterruptType SET ENABLE
}
