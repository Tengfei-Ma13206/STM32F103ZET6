#ifndef __EIE3810_KEY_H
#define __EIE3810_KEY_H
#include "stm32f10x.h"

#define BLACK		0x0000
#define WHITE		0xFFFF
#define BLUE		0x001F
#define GREEN		0x07E0
#define RED			0xF800
#define YELLOW	0xFFE0

#define LCD_COMMAND			((u32) 0x6C000000)
#define LCD_DATA			((u32) 0x6C000800)

#define LCD_LIGHT_ON GPIOB->BSRR |=0x00000001 //Question: What does this line do?


void EIE3810_Key2_EXTIInit(void);
void EIE3810_KeyUp_EXTIInit(void);
void EIE3810_Key0_EXTIInit(void);
void EIE3810_Key1_EXTIInit(void);

void EIE3810_Key_Init(void);
u8 key1_read(void);

#endif
