#include "EIE3810_JOYPAD.h"

void Delay(u32 count)
{
	u32 i;
	for (i=0;i<count;i++);
}

void JOYPAD_Init(void)
{
		RCC->APB2ENR |= 1<<3;// IO port B clock enable
		RCC->APB2ENR |= 1<<5;// IO port D clock enable
		GPIOB->CRH &= 0XFFFF00FF;//CLEAR BIT 8-15 SINCE WE HAVCE PB10 AND PB11
		GPIOB->CRH |= 0X00003800;//OUTPUT mode;General purpose output push-pull FOR 0011
		//; INPUT MODE; Input with pull-up FOR 1000(PB11)
		GPIOB->ODR |= 3<<10;//OUTPUT PORT 10 DATA(PB10)
		GPIOD->CRL &= 0XFFFF0FFF;//CLEAR BIT 12-15 SINCE WE HAVE PD3
		GPIOD->CRL |= 0X00003000;//OUTPUT mode;  General purpose output push-pull
		GPIOD->ODR |= 1<<3;//OUTPUT PORT 3 DATA(PD3)
}

u8 JOYPAD_Read(void)
{
	vu8 temp =0;
	u8 t;
	GPIOB->BSRR |= 1<<11;//PORT B SET BIT 11, MAKE THE JOYPAD ACTIVE
	Delay(80);//DELAY 80 CYCLE
	GPIOB->BSRR |= 1<<27;//PORT B RESET BIT 11, make the joypad not active
	for(t = 0; t <8 ;t++)
	{
		temp>>=1;//shift the original temp right one bit 
		if((((GPIOB->IDR)>>10)&0X01)==0) //Port 10 input data is 0, read the date
			temp|=0x80;//set the 7th bit of temp to be 1
		GPIOD->BSRR |= (1<<3);//port D BIT 3 set, MAKE THE CLOCK CYLE HIGH
		Delay(80);// DELAY 80 CYCLE FOR THE HIGH PULSE
		GPIOD->BSRR |= (1<<19);//port D BIT 3 reset, MAKE THE CLCOK LOW
		Delay(80);//DELAY 80 CYCLE FOR THE LOW PULSE
	}
	return temp;
}
