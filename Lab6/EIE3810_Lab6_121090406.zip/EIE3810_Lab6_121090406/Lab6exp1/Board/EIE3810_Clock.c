#include "EIE3810_Clock.h"

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;
	u8 temp=0;
	RCC->CR |= 0x00010000; //Add comments
	while(!((RCC->CR>>17)&0x1));//Add comments
	RCC->CFGR &= 0xFFFDFFFF; //Add comments
	RCC->CFGR |= 1<<16; //Add comments
	RCC->CFGR |= PLL<<18; //Add comments
	RCC->CR |=0x01000000;//Add comments
	while(!(RCC->CR>>25));//Add comments
	RCC->CFGR &=0xFFFFFFFE;//Add comments
	RCC->CFGR |=0x00000002;//Add comments
	while(temp !=0x02) //Add comments
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; //Add comments
	}	
	
	//MODIFY CHANGE THE FREQUENCY TO 72MHZ
	RCC->CFGR &= 0xFFFFDC0F;//Add comments
	RCC->CFGR |= 0x00000400;//Add comments	
	
//	if (FLASH_ACR_LATENCY == 010 )//STEP2
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	
	//MODIFY
	RCC->APB1ENR |= 1<<17; //Add comments
	RCC->APB2ENR |= 1<<14; //Add comments
}
