#include "stm32f10x.h"
#include "stm32f10x_it.h"
#include <stdlib.h>
#include "EIE3810_TFTLCD.h"
#include "EIE3810_KEY.h"
#include "EIE3810_USART.h"
#include "EIE3810_Buzzer.h"
#include "EIE3810_Clock.h"


u32 ballColor = BLACK;
u32 boardColorA = BLACK;
u32 boardColorB = BLACK;
u8 level;//0 for easy, 1 for hard
u8 status;// 0 for pause, 
					// 1 for selecting difficulty level, 
					// 2 for initialize direction, 
					// 3 for counting down, 
					// 4 for playing, 
					// 5 for game over
u8 direction;//the random number for direction
u8 winner = 0;//A is 0; B is 1

u32 time = 0;
u32 bounceU = 0;//upper play's bounce
u32 bounceD = 0;//lower play's bounce
u32 bounceT = 0;//two play's bounce

u16 x_playerB = 200;//joypad,user 
u16 x_playerA = 200;//key, user 
u16 ballx = 240;//x position of the ball
u16 bally = 400;//y position of the ball
int x_speed = 2;//x axis speed of the ball
int y_speed = 2;//y axis speed of the ball


void changeBoardColorA(void)
{
	if (boardColorA == BLACK) boardColorA = RED;
	else if (boardColorA == RED) boardColorA = YELLOW;
	else if (boardColorA == YELLOW) boardColorA = BLACK;
}

void changeBoardColorB(void)
{
	if (boardColorB == BLACK) boardColorB = RED;
	else if (boardColorB == RED) boardColorB = YELLOW;
	else if (boardColorB == YELLOW) boardColorB = BLACK;
}

void changeBallColor(void)
{
	if (ballColor == BLACK) ballColor = RED;
	else if (ballColor == RED) ballColor = YELLOW;
	else if (ballColor == YELLOW) ballColor = BLACK;
}

// check if the ball hit the pad
u8 isHitPad(void)
{
	int comp;
	if (bally >= 800-5-10-6)//hit user A's pad
	{
		comp = ballx - x_playerA;//the difference between the ball and pad's left side
		bounceD ++;//user point ++
		bounceT ++;//total point ++
		return (ballColor == boardColorA)&(comp <= 80 && comp >= 0);//the difference less than the length
	}
	if (bally<=0+10+6)//hit user B's pad
	{
		comp = ballx - x_playerB;//the difference between the ball and pad's left side
		bounceU ++; //user point ++
		bounceT ++;//total point ++
		return (ballColor == boardColorB)&(comp <= 80 && comp >= 0);//the difference less than the length
	}
	return 0;
}

void moveBall(void)
{
	if (status==0) return;//status is pause
	EIE3810_TFTLCD_DrawCircle(ballx, bally, 10, 1, WHITE); // clear ball
	if (ballx >= 480-10 || ballx<=10)//hit the left and right boundrary
	{
		x_speed = - x_speed;
		Buzzer_Toggle();
		changeBallColor();
	}
	else if (isHitPad())//hit the pad
	{
		y_speed = - y_speed;
		Buzzer_Toggle();
		changeBallColor();
	}
	else if (bally <= 10+1 || bally>=800-10-1)//hit the up and down boundary
	{
		status = 5;//status is game over
		if (bally <= 10 + 1) winner = 0;//A win
		else if (bally >= 800 - 10 - 1) winner = 1;//B win
	}
	ballx = ballx + x_speed;//update position
	bally = bally + y_speed;//update position
	EIE3810_TFTLCD_DrawCircle(ballx, bally, 10, 1, ballColor);//draw the ball
}

void TIM3_IRQHandler(void)
{
	if (TIM3->SR & 1<<0)//update interrupt pending
	{
			if (status==1)//status is selecting difficulty level
			{
				EIE3810_TFTLCD_ShowS2412(20, 200, "Please select the difficulty level:" , 35, WHITE, RED);
				if (level == 0)//easy level
				{
					EIE3810_TFTLCD_ShowS2412(20, 248, "Easy" , 4, WHITE, BLUE);
					EIE3810_TFTLCD_ShowS2412(20, 296, "Hard" , 4, BLUE, WHITE);
				}
				else// hard level
				{
					EIE3810_TFTLCD_ShowS2412(20, 248, "Easy" , 4, BLUE, WHITE);
					EIE3810_TFTLCD_ShowS2412(20, 296, "Hard" , 4, WHITE, BLUE);
				}
				EIE3810_TFTLCD_ShowS2412(20, 344, "Press KEY0 to enter." , 20, WHITE, RED);
				u8 key1 = key1_read();// 1 for press, 0 for release
				u8 keyu = keyu_read();// 1 for press, 0 for release
				u8 key0 = key0_read();// 1 for press, 0 for release
				if (key1)
				{
					level = 1;//change mode to hard
					EIE3810_TFTLCD_ShowS2412(20, 248, "Easy" , 4, BLUE, WHITE);
					EIE3810_TFTLCD_ShowS2412(20, 296, "Hard" , 4, WHITE, BLUE);
				}
				if (keyu)
				{//change mode to easy
					level = 0;
					EIE3810_TFTLCD_ShowS2412(20, 248, "Easy" , 4, WHITE, BLUE);
					EIE3810_TFTLCD_ShowS2412(20, 296, "Hard" , 4, BLUE, WHITE);
				}
				if (key0)
				{//select confirm
					EIE3810_TFTLCD_Clear(WHITE);//clear screen
					status = 2;//change status to selecting direction
				}
			}
			else if (status==2)//status is selecting direction
			{
				EIE3810_TFTLCD_ShowS2412(20, 200, "Use USART for a random direction." , 33, WHITE, RED);
			}
			else if (status==3)//status is counting down from 3 to 1
			{
				for (int i = 0; i < 3; i ++)//count down from 3 to 1
				{
					EIE3810_TFTLCD_FILLRectangle(0,480,0,800,WHITE);//refresh the whole screen
					EIE3810_TFTLCD_SevenSegment(207,330,3 - i,BLUE);//start from the largest number 3
					Delay(10000000);
					EIE3810_TFTLCD_FILLRectangle(0,480,0,800,WHITE);//clear the previous information
				}
				status = 4;//change to playing
			}
			else if (status==4 || status == 0)//status is playing
			{
				u8 joypad = JOYPAD_Read();
				u32 Key2 = (GPIOE->IDR>>2 & 1);//whether key 2 is pressed
				u32 Key0 = (GPIOE->IDR>>4 & 1);//whether key 0 is pressed
				u32 Key1 = (GPIOE->IDR>>3 & 1);//whether key 1 is pressed
				u32 Keyup = keyu_read();
				
				EIE3810_TFTLCD_FILLRectangle(x_playerB, 80, 0, 5, boardColorB);//draw the upper pad
				EIE3810_TFTLCD_FILLRectangle(x_playerA, 80, 800-5, 5, boardColorA);//draw the lower pad
				
				//move the pad for B
					if (((joypad>>3)&0x1) == 0x01)//push start button
					{
						if (status==4)//status is playing
						{
							status = 0;//change status to pause
							EIE3810_TFTLCD_ShowS1608(120,50,"STOP",4,WHITE,BLUE);
							Delay(2000000);
						}
						else if (status==0)//status is pause
						{
							status = 4;//change status to playing
							EIE3810_TFTLCD_ShowS1608(120,50,"STOP",4,WHITE,WHITE);//clear the display
							Delay(2000000);
						}
					}
					else if (((joypad>>6)&0x1) == 0x01)//push left button
					{
						EIE3810_TFTLCD_FILLRectangle(x_playerB, 80, 0, 5, WHITE);
						if (x_playerB > 0)//do not hit the boundarry
						{
							x_playerB--;//move to left
						}
						EIE3810_TFTLCD_FILLRectangle(x_playerB, 80, 0, 5, boardColorB);//draw then new pad
					}
					else if (((joypad>>7)&0x1) == 0x01)//push right button
					{
						EIE3810_TFTLCD_FILLRectangle(x_playerB, 80, 0, 5, WHITE);
						if (x_playerB < 400)//do not hit the boundarry
						{
							x_playerB++;//move to right
						}
						EIE3810_TFTLCD_FILLRectangle(x_playerB, 80, 0, 5, boardColorB);//draw new pad
					}
					else if (((joypad>>4)&0x1) == 0x01)//push up, change board color
					{
						changeBoardColorB();
					}
					
					//control for A
					if (Key0 == 0)//move the pad right
					{
						EIE3810_TFTLCD_FILLRectangle(x_playerA, 80, 800 - 5, 5, WHITE);//clear original pad
						if (x_playerA < 400){
							x_playerA++;//update position
						}
						EIE3810_TFTLCD_FILLRectangle(x_playerA, 80, 800 - 5, 5, boardColorA);//update new pad
					}
					else if (Key2 == 0)//move the pad left
					{
						EIE3810_TFTLCD_FILLRectangle(x_playerA, 80, 800 - 5, 5, WHITE);//clear original pad
						if (x_playerA > 0){
							x_playerA--;//update position
						}
						EIE3810_TFTLCD_FILLRectangle(x_playerA, 80, 800 - 5, 5, boardColorA);//update new pad
					}
					else if (Keyup == 1)//change color of board
					{
						changeBoardColorA();
					}
					else if (Key1 == 0)
					{
						if (status==4)//status is playing
						{
							status = 0;//change to pause
							EIE3810_TFTLCD_ShowS1608(120,50,"STOP",4,WHITE,BLUE);
							Delay(2000000);
						}
						else if (status==0)//status is pause
						{
							status = 4;//change to playing
							EIE3810_TFTLCD_ShowS1608(120,50,"STOP",4,WHITE,WHITE);//clear the display of stop
							Delay(2000000);
						}
					}
					moveBall();
			}
		}
		
		TIM3->SR &= ~(1<<0);//NO UPDATE
}

void TIM4_IRQHandler(void)
{
	if (TIM4->SR & 1<<0)//update interrupt pending
		{
			if(status==4)//status is playing
			{
				//show the time
				EIE3810_TFTLCD_ShowS1608(0,772,"Time:",5,RED,WHITE);
				EIE3810_TFTLCD_ShowNum1608(7*8,772,time,WHITE,WHITE);//clear original
				//show bounce
				EIE3810_TFTLCD_ShowS1608(0,700 - 36,"Bounces for all player:",23,RED,WHITE);
				EIE3810_TFTLCD_ShowNum1608(23*8,700 - 36,bounceT,RED,WHITE);
				EIE3810_TFTLCD_ShowS1608(0,700,"Bounces for the upper player:",29,RED,WHITE);
				EIE3810_TFTLCD_ShowNum1608(29*8,700,bounceU,RED,WHITE);
				EIE3810_TFTLCD_ShowS1608(0,700+36,"Bounces for the lower player:",29,RED,WHITE);
				EIE3810_TFTLCD_ShowNum1608(29*8,736,bounceD,RED,WHITE);
				
				time++;//add the time every second
				EIE3810_TFTLCD_ShowNum1608(7 * 8 ,772,time,RED,WHITE);//show time
			}
		}
		TIM4->SR &= ~(1<<0);
}

void USART1_IRQHandler(void)
{
	u8 buffer;
	if(USART1->SR & (1<<5))//RECEIVE DATA
	{
		if (status != 2) return;
		buffer = USART1->DR;//receive the date
		u8 ascii = buffer + '0';//change the number to char
		direction = buffer;//record the direction

		EIE3810_TFTLCD_ShowS1608(20, 344, "the direction is: " , 18, WHITE, RED);
		EIE3810_TFTLCD_ShowChar(20 + 18 * 8, 344, ascii, WHITE, RED);//show the character
		Delay(10000000);

		status = 3;// change to counting down
		
		//normal case
		if (direction == 0){//vertical downward
			x_speed = 0;
			y_speed = 2;
		}
		else if (direction == 1){//vertical upward
			x_speed = 0;
			y_speed = -2;
		}
		else if (direction % 2 == 1)
		{//left 45
			x_speed = -2;
		}
		else if (direction % 2 == 0)
		{//right 45
			x_speed = 2;
		}
		
		if (level == 1)//hard mode, faster ball
		{
			x_speed *= 2;
			y_speed *= 2;
		}
	}
}

int main(void)
{
	//initialize all the things first
	EIE3810_clock_tree_init();
	JOYPAD_Init();
	EIE3810_TFTLCD_Init();
	EIE3810_TFTLCD_Clear(WHITE);
	EIE3810_NVIC_SetPriorityGroup(5);
	EIE3810_Key_Init();
	EIE3810_USART1_init(72, 9600);//my student id 121090406, baud rate is 9600
	EIE3810_USART1_EXTIInit();
	EIE3810_Buzzer_Init();
	
	while(1)
	{
		winner = 0;//A is 0; B is 1
		time = 0;
		bounceU = 0;//upper play's bounce
		bounceD = 0;//lower play's bounce
		bounceT = 0;//two play's bounce

		x_playerB = 200;//joypad,user 
		x_playerA = 200;//key, user 
		ballx = 240;//x position of the ball
		bally = 400;//y position of the ball
		x_speed = 2;//x position speed of the ball
		y_speed = 2;//y position speed of the ball
		status = 1;
		level = 0;
		//welcome page
		RCC->APB1ENR &= ~(1<<1); //tim3 disable
		RCC->APB1ENR &= ~(1<<2); //tim4 disable
		EIE3810_TFTLCD_Clear(WHITE);
		EIE3810_TFTLCD_ShowS2412(100, 200, "Welcome to mini Project!" , 24, WHITE, BLUE);
		Delay(6000000);
		EIE3810_TFTLCD_ShowS1608(112, 248, "This is the Final Lab." , 22, WHITE, RED);
		Delay(6000000);
		EIE3810_TFTLCD_ShowS1608(112, 296, "Are you ready?" , 14, WHITE, RED);
		Delay(6000000);
		EIE3810_TFTLCD_ShowS1608(112, 344, "OK! Let's start." , 16, WHITE, RED);
		Delay(6000000);
		EIE3810_TFTLCD_Clear(WHITE);//clear the screen

		EIE3810_TIM3_Init(99,7199);//set the counter number + 1 to be 99
		
		while(1)
		{
			if (status==0)//status is pause
			{
				while(status==0);//wait pause over
			}
			else if (status==4)//status is playing
				EIE3810_TIM4_Init(9999,7199);//the frequency is 1Hz
			else if (status == 5)//status is game over
			{
				EIE3810_TFTLCD_FILLRectangle(0,480,0,800,WHITE);//clear the whole screen

				EIE3810_TFTLCD_ShowS2412(10,200,"The Winner is: ",15, BLACK, WHITE);//show the detail of the information
				if (winner == 0)//winner is A
					EIE3810_TFTLCD_ShowS2412(10 + 15 * 12,200,"A",1, BLACK, WHITE);//show the name of A
				else //winner is B
					EIE3810_TFTLCD_ShowS2412(10 + 15 * 12,200,"B",1, BLACK, WHITE);//show the name of B
				boardColorA = BLACK;
				boardColorB = BLACK;
				ballColor = BLACK;
				Delay(30000000);
				break;
			}
			
		}
	}
}
