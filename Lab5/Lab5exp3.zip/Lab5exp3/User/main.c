#include "stm32f10x.h"

void EIE3810_clock_tree_init(void);
void EIE3810_TIM3_Init(u16 arr, u16 psc);
void TIM3_IRQHandler(void);
void EIE3810_LED_Init(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_TIM4_Init(u16 arr, u16 psc);
void Delay(u32);

u16 task1HeartBeat;
u16 task2HeartBeat;

void EIE3810_SYSTICK_Init()
{
	SysTick->CTRL=0;//clear SysTick->CTRL setting
	
	SysTick->LOAD=90000-1;//the sysclock is 72MHz / 8, 10ms one interrupt means 100Hz, so need to count 72*10^6 / (8*100) = 90000times
	//SysTick->LOAD= 45000-1;//systick = 200Hz
	
	SysTick->CTRL|=1<<0;//counter operator in a multi-short way.
	SysTick->CTRL|=1<<1;//counting down to 0 pends the SysTick handler 
	
	//CLKSOURCE=0: FCLK/8
	//CLKSOURCE=1: FCLK
	//CLKSOURCE=0 is synchronized and better than CLKSOURCE=1
}

int main(void)
{
	EIE3810_clock_tree_init();//initialize clock tree
	EIE3810_LED_Init();//initialize LED
	EIE3810_NVIC_SetPriorityGroup(5);//set PRIGROUP as 5
	EIE3810_SYSTICK_Init();//initialize systick

	GPIOE->ODR |=1<<5;// turn off DS1
	GPIOB->ODR |=1<<5;// turn off DS0
	//GPIOE->BSRR=1<<5;
	//GPIOB->BSRR=1<<5;
	
	while(1)
	{
		if (task1HeartBeat>=10)
		{
			GPIOB->ODR ^=1<<5;//flip PB5
			task1HeartBeat=0;//load task1HeartBeat as 0
		}
		if (task2HeartBeat>=25)
		{
			GPIOE->ODR ^=1<<5;//flip PE5
			task2HeartBeat=0;//load task2HeartBeat as 0
		}
	}

}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;//0111 -> PLL input clock * 9
	u8 temp=0;
	RCC->CR |= 0x00010000; //Enable High Speed External oscillator: set bit16 of control register as 1
	while(!((RCC->CR>>17)&0x1));//waitting for HSE oscillator ready
	RCC->CFGR &= 0xFFFDFFFF; //bit 17 is 1, HSE not divided
	RCC->CFGR |= 1<<16; //bit 16 is 1, the HSE is sellected as PLL input clock
	RCC->CFGR |= PLL<<18; //0111, PLL input clock*9 (72Hz)
	RCC->CR |=0x01000000;//Enable PLL
	while(!(RCC->CR>>25));//wait for PLL locked: be stable
	RCC->CFGR &=0xFFFFFFFE;//prepare for PLL selection
	RCC->CFGR |=0x00000002;//CFGR=10, PLL selected as system clock
	while(temp !=0x02) //check if PLL is used as system clock
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; // Assign system clock switch status to temp
	}	
	RCC->CFGR &= 0xFFFFFC0F;//bit 4-7(x second)for AHB clock, AHB not divided. 
	RCC->CFGR |= 0x00000400;//bit 11,10,9,8=x100,for APB1's PLCK1, HCLK divided by 2(36Hz)
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //USART2 clock enable
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	RCC->APB1ENR|=1<<1;//TIM3 enable
	TIM3->ARR=arr;//counting arr times and generated the interrupt
	TIM3->PSC=psc;//set the prescalar
	TIM3->DIER|=1<<0;//Update interrupt enabled
	TIM3->CR1|=0x01;//counter and UEV enable
	NVIC->IP[29]=0x45;//set interrupt priority of TIM3 as 0100 0101
	NVIC->ISER[0]=(1<<29);//enable the interrupt,TIM3 corresponds to 29
}

void EIE3810_TIM4_Init(u16 arr, u16 psc)//need program
{
	RCC->APB1ENR|=1<<2;//TIM4 enable
	TIM4->ARR=arr;//counting arr times and generated the interrupt
	TIM4->PSC=psc;//set the prescalar
	TIM4->DIER|=1<<0;//Update interrupt enabled
	TIM4->CR1|=0x01;//counter and UEV enable
	NVIC->IP[30]=0x40;//set interrupt priority of TIM4 as 1000 0000
	NVIC->ISER[0]=(1<<30);////enable the interrupt TIM4
}
void TIM3_IRQHandler(void)
{
	if (TIM3->SR & 1<<0)//detected the update event
	{
		GPIOB->ODR ^=1<<5;//flip the status of PB5
	}
	TIM3->SR &=~(1<<0);//clear updated interrupt pending status
}
	
	
void TIM4_IRQHandler(void)
{
	if (TIM4->SR & 1<<0)//detected the update event
	{
		GPIOE->ODR ^=1<<5;//flip the status of PE5
	}
	TIM4->SR &=~(1<<0);//clear updated interrupt pending status
}


void EIE3810_LED_Init(void)
{
	//set led
	RCC->APB2ENR|=1<<3;//enable GPIOB
	RCC->APB2ENR|=1<<6;//enable GPIOE
	GPIOB->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to perpared to set pb5
	GPIOE->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to perpared to set pb5
	GPIOB->CRL|=0x00300000;//PB5 (led0)general purpouse output push pull 
	GPIOE->CRL|=0x00300000;//set pe5(led1) to output push put
}
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1,temp2;
	temp2=prigroup&0x00000007;//0x7=0b0111, pick the lowest 3 bits
	temp2<<=8;//move to bit 8-10, the grouping field
	temp1=SCB->AIRCR;//get the previous value of AIRCR
	temp1 &=0x0000F8FF;//get bit 0-16 of temp1, 8,9,10 bit is 0
	temp1 |=0x05FA0000;//On writes, write 0x5FA to VECTKEY, otherwise the write is ignored
	temp1 |=temp2;//put the bit 8-10 (PRIGROUP) of temp2 into temp1
	SCB->AIRCR=temp1;//assign prepared temp1 to AIRCR
}
	
