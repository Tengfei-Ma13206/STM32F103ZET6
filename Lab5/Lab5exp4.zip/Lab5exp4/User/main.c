#include "stm32f10x.h"

void EIE3810_clock_tree_init(void);
void EIE3810_TIM3_PWMInit(u16 arr, u16 psc);
void EIE3810_LED_Init(void);
void Delay(u32);


#define LED0_PWM_VAL TIM3->CCR2


int main(void)
{
	u16 LED0PWMVal=0;
	u8 dir=1;//counting direction
	EIE3810_clock_tree_init();//initialize clock tree
	EIE3810_LED_Init();//initialize LED
	EIE3810_TIM3_PWMInit(9999, 71);//divided the clock by 10000*72
	while(1)
	{
		Delay(1500);
		if (dir) LED0PWMVal++;//count up
		else LED0PWMVal--;//count down
		if (LED0PWMVal>5000)dir=0;//set count down,adjust the duty cycle low--high--low
		if (LED0PWMVal==0) dir=1;//set count up
		LED0_PWM_VAL = LED0PWMVal;//write into the TIM3->CCR2
		//LED0_PWM_VAL = 10000;//what happened if set LED0_PWM_VAL = 0,9999,10000
	}
}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}
void EIE3810_TIM3_PWMInit(u16 arr, u16 psc)
{
	RCC->APB2ENR|=1<<3;//Enable GPIOB
	GPIOB->CRL&=0xFF0FFFFF;//prepare for enable PB5
	GPIOB->CRL|=0x00B00000;//enable PB5 as output with max speed 50MHz
	RCC->APB2ENR|=1<<0;//enable alternate function IO
	AFIO->MAPR&=0xFFFFF3FF;//reset AFIO remap
	AFIO->MAPR|=1<<11;//specific remap configuration
	RCC->APB1ENR|=1<<1;//enable clock for TIM3
	TIM3->ARR=arr;//set auto-reload value for TIM3
	TIM3->PSC=psc;//set the prescaler for TIM3
	TIM3->CCMR1|=7<<12;//set the output compare mode for TIM3
	TIM3->CCMR1|=1<<11;//enable output compare preload for TIM3
	TIM3->CCER|=1<<4;//Enable capture/compare for TIM3 channel 2.
	TIM3->CR1=0x0080;//TIMx_ARR register is buffered
	TIM3->CR1|=1<<0;//enable counter of TIM3
}
void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;//0111 -> PLL input clock * 9
	u8 temp=0;
	RCC->CR |= 0x00010000; //Enable High Speed External oscillator: set bit16 of control register as 1
	while(!((RCC->CR>>17)&0x1));//waitting for HSE oscillator ready
	RCC->CFGR &= 0xFFFDFFFF; //bit 17 is 1, HSE not divided
	RCC->CFGR |= 1<<16; //bit 16 is 1, the HSE is sellected as PLL input clock
	RCC->CFGR |= PLL<<18; //0111, PLL input clock*9 (72Hz)
	RCC->CR |=0x01000000;//Enable PLL
	while(!(RCC->CR>>25));//wait for PLL locked: be stable
	RCC->CFGR &=0xFFFFFFFE;//prepare for PLL selection
	RCC->CFGR |=0x00000002;//CFGR=10, PLL selected as system clock
	while(temp !=0x02) //check if PLL is used as system clock
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; // Assign system clock switch status to temp
	}	
	RCC->CFGR &= 0xFFFFFC0F;//bit 4-7(x second)for AHB clock, AHB not divided. 
	RCC->CFGR |= 0x00000400;//bit 11,10,9,8=x100,for APB1's PLCK1, HCLK divided by 2(36Hz)
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //USART2 clock enable
}

void EIE3810_LED_Init(void)
{
	//set led
	RCC->APB2ENR|=1<<3;//enable GPIOB
	RCC->APB2ENR|=1<<6;//enable GPIOE
	GPIOB->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to perpared to set pb5
	GPIOE->CRL &=0xFF0FFFFF;//clear the bit 20,21,22,23 to perpared to set pb5
	GPIOB->CRL|=0x00300000;//PB5 (led0)general purpouse output push pull 
	GPIOE->CRL|=0x00300000;//set pe5(led1) to output push put
}


