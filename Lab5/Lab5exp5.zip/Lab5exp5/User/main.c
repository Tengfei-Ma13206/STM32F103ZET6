#include "stm32f10x.h"
#include "EIE3810_TFTLCD.h"
#include "Font.H"

void EIE3810_clock_tree_init(void);
void EIE3810_TIM3_Init(u16 arr, u16 psc);
void TIM3_IRQHandler(void);
void EIE3810_NVIC_SetPriorityGroup(u8 prigroup);
void EIE3810_TIM4_Init(u16 arr, u16 psc);
void PrintString(u16 x, u16 y, char*st, u16 color, u16 bgcolor);

u8 jup;
void Delay(u32);

void EIE3810_SYSTICK_Init()
{
	SysTick->CTRL=0;//clear SysTick->CTRL setting
	
	SysTick->LOAD=90000-1;//the sysclock is 72MHz / 8, 10ms one interrupt means 100Hz, so need to count 72*10^6 / (8*100) = 90000times
	//SysTick->LOAD= 45000-1;//systick = 200Hz
	
	SysTick->CTRL|=1<<0;//counting down to 0 pend the handler
	SysTick->CTRL|=1<<1;//counter operator in a multi-short way.
	
	//CLKSOURCE=0: FCLK/8
	//CLKSOURCE=1: FCLK
	//CLKSOURCE=0 is synchronized and better than CLKSOURCE=1
	
}
void JOPAD_Init(void)
{
	RCC->APB2ENR|=1<<3;//Enable clock for I/O port B
	RCC->APB2ENR|=1<<5;//Enable clock for I/O port D
	GPIOB->CRH&=0xFFFF00FF;//Reset the configuration of GPIOB high pins 
	GPIOB->CRH|=0x00003800;//Configure GPIOB pin 10 and 11 as output with max speed 50 MHz
	GPIOB->ODR|=3<<10;//Set the output data register for GPIOB pins 10 and 11 to high
	GPIOD->CRL&=0xFFFF0FFF;//Reset the configuration of GPIOD low pin
	GPIOD->CRL|=0x00003000;//Configure GPIOD pin 3 as output with max speed 50 MHz
	GPIOD->ODR|=1<<3;//Set the output data register for GPIOD pin 3 to high
}
void JOYPAD_DELAY(u16 t)
{
	while(t--);
}
u8 JOYPAD_Read(void)
{
	vu8 temp=0;
	u8 t;
	GPIOB->BSRR |=1<<11;//Set GPIOB pin 11 to high
	Delay(80);//delay 80
	GPIOB->BSRR|=1<<27;//Resets pin11 of GPIOB to low
	//after PB11 have one pulse, the for loop would pulse PD3 eght times to read the PB10.
	for (t=0;t<8;t++)
	{
		temp>>=1;//shift right 1 bit
//move right 1 bit,at t moment if the input is received in line 53, it would move right 8-n step, so when t=0 it received, temp=0b1
		if((((GPIOB->IDR)>>10)&0x01)==0) temp|=0x80;//0x80=0b0100, if the input signal is in this period, it would get this value
		GPIOD->BSRR |=(1<<3);//Set GPIOD pin 3 to high
		Delay(80);//delay 80
		GPIOD->BSRR|=(1<<19);//Resets GPIOD pin 3 to low
		Delay(80);//delay 80
	}
	return temp;
}


void EIE3810_TFTLCD_ShowChar(u16 x, u16 y, u8 ASCII, u16 color, u16 bgcolor)
{
	u8 column=0;// the pattern of one column
	for (u16 i=0;i<16;i++)
	{
		column=asc2_1608[ASCII-32][i];
		for (u16 j=0;j<8;j++)// bit j of column
		{
			if ((column%2)==1)// the bit j of column is 1
			{
				if (i%2==0)//upper column
				{
					EIE3810_TFTLCD_DrawDot(x+i/2, y+8-j, color);// draw dot of character
				}
				else// lower column
				{
					EIE3810_TFTLCD_DrawDot(x+(i-1)/2, y+(16-j),color);// draw dot of character
				}
			}
			else// the bit j of column is 0
			{
				if (i%2==0)//upper column
				{
					EIE3810_TFTLCD_DrawDot(x+i/2, y+8-j, bgcolor);// draw dot of character background
				}
				else//lower column
				{
					EIE3810_TFTLCD_DrawDot(x+(i-1)/2, y+(16-j),bgcolor);// draw dot of character background
				}
			}
			column=column/2;//remove the LSB of column
			
		}
	}
}

void PrintString(u16 x, u16 y, char*st, u16 color, u16 bgcolor)
{
	u16 charWidth=9;//width of every character
	u8 i=0;
	while (st[i]!=0x00)
	{
		EIE3810_TFTLCD_ShowChar(x+i*charWidth, y,st[i], color, bgcolor);//print character
		if (i==59) break;// max nunber of character is 60
		i++;
	}
		
}

int main(void)
{
	EIE3810_clock_tree_init();//initialize clock tree
	JOPAD_Init();//initialize joypad
	EIE3810_NVIC_SetPriorityGroup(5);//set PRIGROUP as 5
	EIE3810_TIM3_Init(4999, 71);//initialize TIM3
	EIE3810_TFTLCD_Init();//initialize LCD

	Delay(500000);
	EIE3810_TFTLCD_Clear(WHITE);
	
	u8 cu=0;
	
	while(1)
	{
		if (cu!=jup)
		{
			if (jup==1)
			{
				PrintString(200, 200, "A     ", BLACK,WHITE);
			}
			else if (jup==2)
			{
				PrintString(200, 200, "B     ", BLACK,WHITE);
			}
			else if (jup==4)
			{
				PrintString(200, 200, "SELECT", BLACK,WHITE);
			}
			else if (jup==8)
			{
				PrintString(200, 200, "START ", BLACK,WHITE);
			}
			else if (jup==16)
			{
				PrintString(200, 200, "UP    ", BLACK,WHITE);
			}
			else if (jup==32)
			{
				PrintString(200, 200, "DOWN  ", BLACK,WHITE);
			}
			else if (jup==64)
			{
				PrintString(200, 200, "LEFT  ", BLACK,WHITE);
			}
			else if (jup==128)
			{
				PrintString(200, 200, "RIGHT ", BLACK,WHITE);
			}
			cu=jup;
		}
	}

}

void Delay(u32 count) 
{
	u32 i;
	for (i=0;i<count;i++);
}

void EIE3810_clock_tree_init(void)
{
	u8 PLL=7;//0111 -> PLL input clock * 9
	u8 temp=0;
	RCC->CR |= 0x00010000; //Enable High Speed External oscillator: set bit16 of control register as 1
	while(!((RCC->CR>>17)&0x1));//waitting for HSE oscillator ready
	RCC->CFGR &= 0xFFFDFFFF; //bit 17 is 1, HSE not divided
	RCC->CFGR |= 1<<16; //bit 16 is 1, the HSE is sellected as PLL input clock
	RCC->CFGR |= PLL<<18; //0111, PLL input clock*9 (72Hz)
	RCC->CR |=0x01000000;//Enable PLL
	while(!(RCC->CR>>25));//wait for PLL locked: be stable
	RCC->CFGR &=0xFFFFFFFE;//prepare for PLL selection
	RCC->CFGR |=0x00000002;//CFGR=10, PLL selected as system clock
	while(temp !=0x02) //check if PLL is used as system clock
	{
		temp=RCC->CFGR>>2;
		temp &= 0x03; // Assign system clock switch status to temp
	}	
	RCC->CFGR &= 0xFFFFFC0F;//bit 4-7(x second)for AHB clock, AHB not divided. 
	RCC->CFGR |= 0x00000400;//bit 11,10,9,8=x100,for APB1's PLCK1, HCLK divided by 2(36Hz)
	FLASH->ACR = 0x32;//Set FLASH with 2 wait states	
	RCC->APB1ENR |= 1<<17; //USART2 clock enable
}

void EIE3810_TIM3_Init(u16 arr, u16 psc)
{
	RCC->APB1ENR|=1<<1;//TIM3 enable
	TIM3->ARR=arr;//counting arr times and generated the interrupt
	TIM3->PSC=psc;//set the prescalar
	TIM3->DIER|=1<<0;//Update interrupt enabled
	TIM3->CR1|=0x01;//counter and UEV enable
	NVIC->IP[29]=0x45;//set interrupt priority of TIM3 as 0100 0101
	NVIC->ISER[0]=(1<<29);//enable the interrupt,TIM3 corresponds to 29
}

void EIE3810_TIM4_Init(u16 arr, u16 psc)
{
	RCC->APB1ENR|=1<<2;//TIM4 enable
	TIM4->ARR=arr;//counting arr times and generated the interrupt
	TIM4->PSC=psc;//set the prescalar
	TIM4->DIER|=1<<0;//Update interrupt enabled
	TIM4->CR1|=0x01;//counter and UEV enable
	NVIC->IP[30]=0x40;//set interrupt priority of TIM4 as 1000 0000
	NVIC->ISER[0]=(1<<30);////enable the interrupt TIM4
}
void TIM3_IRQHandler(void)
{
	if (TIM3->SR & 1<<0)//detected the update event
	{
		jup=JOYPAD_Read();//read joypad
	}
	TIM3->SR &=~(1<<0);//clear updated interrupt pending status
}
	
	
void TIM4_IRQHandler(void)
{
	if (TIM4->SR & 1<<0)//detected the update event
	{
		GPIOE->ODR ^=1<<5;//flip the status of PE5
	}
	TIM4->SR &=~(1<<0);//clear updated interrupt pending status
}


void EIE3810_NVIC_SetPriorityGroup(u8 prigroup)
{
	u32 temp1,temp2;
	temp2=prigroup&0x00000007;//0x7=0b0111, pick the lowest 3 bits
	temp2<<=8;//move to bit 8-10, the grouping field
	temp1=SCB->AIRCR;//get the previous value of AIRCR
	temp1 &=0x0000F8FF;//get bit 0-16 of temp1, 8,9,10 bit is 0
	temp1 |=0x05FA0000;//On writes, write 0x5FA to VECTKEY, otherwise the write is ignored
	temp1 |=temp2;//put the bit 8-10 (PRIGROUP) of temp2 into temp1
	SCB->AIRCR=temp1;//assign prepared temp1 to AIRCR
}
	
