#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "EIE3810_LED.h"
#include "EIE3810_KEY.h"
#include "EIE3810_Buzzer.h"
int main(void)
{
	//initialize device
	EIE3810_LED_Init();
	EIE3810_Buzzer_Init();
	EIE3810_Key_Init();
	
	while(1)
	{
		if(EIE3810_Read_Key2() == 1)//release Key2
		{
			EIE3810_TurnOff_LED0();//turn off LED0
		}
		else
		{
			EIE3810_TurnOn_LED0();//turn on LED0
		}
		
		if(EIE3810_Read_Key1() == 0)//press Key1
		{
			EIE3810_toggle_LED1();//toggle LED1
		}
		
		if(EIE3810_Read_KeyUp() == 1)//press Key_up
		{
			EIE3810_toggle_Buzzer();//toggle buzzer
		}
	}
}

