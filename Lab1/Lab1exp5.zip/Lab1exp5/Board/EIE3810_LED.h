#ifndef __EIE3810_LED_H
#define __EIE3810_LED_H
#include "stm32f10x.h"

// put procudure header here
void EIE3810_LED_Init(void);
void EIE3810_LED_Work(void);
void EIE3810_TurnOn_LED0(void);
void EIE3810_TurnOff_LED0(void);
void EIE3810_toggle_LED1(void);
#endif
