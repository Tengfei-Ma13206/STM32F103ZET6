#include "stm32f10x.h"
#include "EIE3810_LED.h"

// put your code here
void EIE3810_LED_Init(void)
{
	RCC->APB2ENR|=1<<3;//PBstart
	RCC->APB2ENR|=1<<6;//PEstart
	
	//PB5
	GPIOB->CRL &=0xFF0FFFFF;
	GPIOB->CRL|=0x00300000;//mode_out_pp 
	//PE5
	GPIOE->CRL &=0xFF0FFFFF;
	GPIOE->CRL|=0x00300000;//mode_out_pp 
}

void EIE3810_TurnOn_LED0(void)
{
	GPIOB->BRR|=1<<5;//PB5=0
}

void EIE3810_TurnOff_LED0(void)
{
	GPIOB->BSRR|=1<<5;//PB5=1
}

void EIE3810_toggle_LED1(void)
{
			for(int i = 0; i < 200000; i++);//delay for turbulence
	
			if (((GPIOE->IDR>>3)&0x1) == 0)
			{
				//swap status
				if ((GPIOE->ODR>>5&0x1) == 1) GPIOE->BRR|=1<<5;
				else GPIOE->BSRR|=1<<5;
				
				while(((GPIOE->IDR>>3)&0x1) == 0);//wait for continuous pressing Key1
				
				for(int i = 0; i < 200000; i++);//delay for turbulence
			}
}
