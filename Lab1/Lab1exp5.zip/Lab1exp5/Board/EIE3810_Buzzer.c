#include "stm32f10x.h"
#include "EIE3810_Buzzer.h"

// put your procedure and code here
void EIE3810_Buzzer_Init(void)
{
	RCC->APB2ENR|=1<<3;//PBstart
	//PB8
	GPIOB->CRH &=0xFFFFFFF0;
	GPIOB->CRH|=0x00000003;//mode_out_pp 
}

void EIE3810_toggle_Buzzer(void)
{
		//key_up-buzzer: PA0-PB8		
			for(int i = 0; i < 100000; i++);//Delay 100000 for turbulence
			if (((GPIOA->IDR)&0x1) == 1)
			{
				//swap status
				if ((GPIOB->ODR>>8&0x1) == 1) GPIOB->BRR|=1<<8;
				else GPIOB->BSRR|=1<<8;
				
				while(((GPIOA->IDR)&0x1) == 1)ADC1;//wait continuous press Key_up
				
				for(int i = 0; i < 100000; i++);//Delay 100000 for turbulence
			}
}
