#include "stm32f10x.h"
#include "EIE3810_KEY.h"

// put your procedure and code here
void EIE3810_Key_Init(void)
{
	RCC->APB2ENR|=1<<2;//PAstart
	RCC->APB2ENR|=1<<6;//PEstart
	
	//PE2
	GPIOE->CRL &=0xFFFFF0FF;
	GPIOE->CRL|=0x00000800;//mode_ipu 
	GPIOE->ODR |=1<<2;//PE2 
	//PE3
	GPIOE->CRL &=0xFFFF0FFF;
	GPIOE->CRL|=0x00008000;//mode_ipu 
	GPIOE->ODR |=1<<3;//PE3
	//PA0
	GPIOA->CRL &=0xFFFFFFF0;
	GPIOA->CRL|=0x00000008;//mode_ipu 
	GPIOA->ODR |=1<<1;//PA0 
}

int EIE3810_Read_Key1(void)
{	
	return (GPIOE->IDR>>3)&0x1;
}

int EIE3810_Read_Key2(void)
{
	return (GPIOE->IDR>>2)&0x1;
}

int EIE3810_Read_KeyUp(void)
{
	return (GPIOA->IDR)&0x1;
}
