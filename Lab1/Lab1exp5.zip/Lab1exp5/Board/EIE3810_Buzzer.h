#ifndef __EIE3810_BUZZER_H
#define __EIE3810_BUZZER_H
#include "stm32f10x.h"

// put procedure header here
void EIE3810_Buzzer_Init(void);
void EIE3810_toggle_Buzzer(void);

#endif
