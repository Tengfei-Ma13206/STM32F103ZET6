#include "stm32f10x.h"

void Delay(u32 count)
{
	u32 i;
	for (i=0; i < count; i++);
}
int main(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);//enable PB
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;            //set as Pin5
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    //set as 50MHz
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     //set output mode as push-pull
	GPIO_Init(GPIOB, &GPIO_InitStructure);               //initialize PB5
	GPIO_SetBits(GPIOB, GPIO_Pin_5);                     //set PB5 as high
	while(1)
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_5);                 //set PB5 as low
		Delay(10000000);                                   //delay 1 second
		GPIO_SetBits(GPIOB, GPIO_Pin_5);                   //set PB5 as high
		Delay(10000000);                                   //delay 1 second
	}
}
