#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
void Delay(u32 count)
{
	u32 i;
	for (i=0; i < count; i++);
}

int main(void)
{
	//Initialize PE2
	GPIO_InitTypeDef GPIO_PE2;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE); //enable PE
	GPIO_PE2.GPIO_Pin = GPIO_Pin_2;
	GPIO_PE2.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_PE2.GPIO_Mode = GPIO_Mode_IPU;   // set PE2 as pull-up input
	GPIO_Init(GPIOB, &GPIO_PE2);
	
	//Initialize PB5
	GPIO_InitTypeDef GPIO_PB5;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); //enable PB
	GPIO_PB5.GPIO_Pin = GPIO_Pin_5;
	GPIO_PB5.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_PB5.GPIO_Mode = GPIO_Mode_Out_PP;  //set PB5 as push-pull output
	GPIO_Init(GPIOB, &GPIO_PB5);
	GPIO_SetBits(GPIOB, GPIO_Pin_5); //set PB5 as high
	
	while(1)
	{
		if (GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == 0) //PE2 is connected to Key2, Pressing Key2 makes PE2 low.
		{
			GPIO_ResetBits(GPIOB, GPIO_Pin_5); //when pressing Key2, PB5 (LED0) is lit.
		}
		else
		{
			GPIO_SetBits(GPIOB, GPIO_Pin_5); //when releasing Key2, PB5(LED0) is off.
		}
	}
}

