#include "stm32f10x.h"
#include "stm32f10x_gpio.h"

int main(void)
{
	//start
	RCC->APB2ENR|=1<<2;//PAstart
	RCC->APB2ENR|=1<<3;//PBstart
	RCC->APB2ENR|=1<<6;//PEstart
	
	//mode
	//PB5
	GPIOB->CRL &=0xFF0FFFFF;
	GPIOB->CRL|=0x00300000;//mode_out_pp 
	//PE5
	GPIOE->CRL &=0xFF0FFFFF;
	GPIOE->CRL|=0x00300000;//mode_out_pp 
	//PB8 buzzer
	GPIOB->CRH &=0xFFFFFFF0;
	GPIOB->CRH|=0x00000003;//mode_out_pp 
	
	
	//PE2
	GPIOE->CRL &=0xFFFFF0FF;
	GPIOE->CRL|=0x00000800;//mode_ipu 
	GPIOE->ODR |=1<<2;//PE2 
	//PE3
	GPIOE->CRL &=0xFFFF0FFF;
	GPIOE->CRL|=0x00008000;//mode_ipu 
	GPIOE->ODR |=1<<3;//PE3
	//PA0
	GPIOA->CRL &=0xFFFFFFF0;
	GPIOA->CRL|=0x00000008;//mode_ipu 
	GPIOA->ODR |=1<<1;//PA0
	
	
	while(1)
	{
		//key2-LED0: PE2-PB5
		if (((GPIOE->IDR>>2)&0x1) == 1)//release Key2
		{
			GPIOB->BSRR|=1<<5;//PB5=1 : LED0 is off
		}
		else
		{
			GPIOB->BRR|=1<<5;//PB5=0 : LED0 is lit
		}
		
		//key1-LED1: PE3-PE5
		if (((GPIOE->IDR>>3)&0x1) == 0)//press Key1
		{
			for(int i = 0; i < 200000; i++);//delay for turbulence at the beginning of pressing
			
			if (((GPIOE->IDR>>3)&0x1) == 0)
			{
				//change status of LED1 when pressing Key1
				if ((GPIOE->ODR>>5&0x1) == 1) GPIOE->BRR|=1<<5;
				else GPIOE->BSRR|=1<<5;
				
				while(((GPIOE->IDR>>3)&0x1) == 0);//wait for continuous pressing
				
				for(int i = 0; i < 200000; i++);//delay for turbulence at the beginning of releasing
			}
		}
		
		//key_up-buzzer: PA0-PB8		
		if (((GPIOA->IDR)&0x1) == 1)//press Key_up
		{
			for(int i = 0; i < 80000; i++);//delay for turbulence at the beginning of pressing
			
			if (((GPIOA->IDR)&0x1) == 1)
			{
				//change status of buzzer when pressing Key_up
				if ((GPIOB->ODR>>8&0x1) == 1) GPIOB->BRR|=1<<8;
				else GPIOB->BSRR|=1<<8;
				
				while(((GPIOA->IDR)&0x1) == 1);//wait for continuous pressing
				
				for(int i = 0; i < 80000; i++);//delay for turbulence at the beginning of releasing
			}
		}
		
	}

}

