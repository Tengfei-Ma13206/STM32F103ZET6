#include "stm32f10x.h"

void Delay(u32 count)
{
	u32 i;
	for (i=0; i < count; i++);
}
int main(void)
{
	RCC->APB2ENR|=1<<3; //enable PB
	//set PB5 as push-pull output
	GPIOB->CRL &=0xFF0FFFFF;
	GPIOB->CRL|=0x00300000;
	
	while(1)
	{
		GPIOB->BRR=1<<5;//reset PB5(LED0)
		Delay(10000000);//delay 1 sec
		GPIOB->BSRR=1<<5;//set PB5(LED0)
		Delay(10000000);//delay 1 sec
	}
}

